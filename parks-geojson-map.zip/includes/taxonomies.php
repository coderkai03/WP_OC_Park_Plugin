<?php
/**
 * CPT OC-Park and taxonomies (Amenities, Activities) are registered elsewhere.
 * This file is kept for future plugin hooks if needed.
 */

defined('ABSPATH') || exit;
